const chatWindow = document.getElementById("chat-window");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
function appendMessage(message, sender) {
    const msgDiv = document.createElement("div");
    msgDiv.classList.add("chat-message", sender === "user" ? "user-message" : "bot-message");
    msgDiv.textContent = message;
    chatWindow.appendChild(msgDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;
    // Append user message
    appendMessage(message, "user");
    userInput.value = "";
    // Show thinking message
    displayThinkingMessage();
    try {
        // Simulate a delay for the bot's response
        const res = await fetch("http://localhost:5000/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message })
        });
        // Wait for a delay before processing the response
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2 seconds delay
        const data = await res.json();
        // Remove thinking message and append bot's response
        removeThinkingMessage();
        appendMessage(data.reply, "bot");
    } catch (error) {
        removeThinkingMessage();
        appendMessage("⚠️ Server error. Try again later.", "bot");
    }
}

function displayThinkingMessage() {
    const thinkingMessage = document.createElement("div");
    thinkingMessage.classList.add("chat-message", "bot-message");
    thinkingMessage.innerHTML = "<em>🤔 Thinking...</em>";
    chatWindow.appendChild(thinkingMessage);
    chatWindow.scrollTop = chatWindow.scrollHeight; // Scroll to the bottom
}
function removeThinkingMessage() {
    const messages = chatWindow.getElementsByClassName("bot-message");
    if (messages.length > 0) {
        const lastMessage = messages[messages.length - 1];
        if (lastMessage.textContent.includes("Thinking...")) {
            chatWindow.removeChild(lastMessage);
        }
    }
}
sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage();
});
const darkToggleBtn = document.getElementById("darkModeToggle");

window.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("chatTheme");
  if (savedTheme === "light") {
    document.body.classList.add("light-mode");
  }

  darkToggleBtn.addEventListener("click", () => {
    document.body.classList.toggle("light-mode");
    const isLight = document.body.classList.contains("light-mode");
    localStorage.setItem("chatTheme", isLight ? "light" : "dark");
  });
});
